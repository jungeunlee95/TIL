package Day10Homework04;

public class LottoMain {

	public static void main(String[] args) {
		//���� 4
		System.out.println("lotto game 4");
		new LottoVw().start();
		
	}

}
