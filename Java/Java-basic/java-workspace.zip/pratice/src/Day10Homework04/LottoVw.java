package Day10Homework04;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class LottoVw {
	private Scanner sc = new Scanner(System.in);

	public void start() {

		System.out.println("���Ӽ��� �Է��ϼ��� : ");
		// Double.parseDouble(sc.nextLine()); ������ ���� ��,
		int gameCnt = Integer.parseInt(sc.nextLine());

		for (int i = 1; i < gameCnt + 1; i++) {
			System.out.println(i + "���� : " + getLottoNums());
		}

	}

	private String getLottoNums() {
		// �ݷ��� ��� set-�ߺ�X
		Set<Integer> lottoNums = new HashSet<Integer>();
		
		Random r = new Random();
		
		while(lottoNums.size() < 6 ) {
		lottoNums.add(r.nextInt(45) + 1);
		}
		
		return Arrays.toString(lottoNums.toArray());
		

	}

	

}









