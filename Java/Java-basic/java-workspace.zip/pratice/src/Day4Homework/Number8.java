package Day4Homework;

/*
 ������ ����� ���̴� ���α׷� �ۼ�

   num1 : 12
   num2 : 9
   num2 : 15
   num2 : 6
   num3 : 94
   num4 : 6
   num5 : 11
   num5 : 12
   
   < PRINT >
   12  6  94  6  12
   
 */

import java.util.Scanner;

public class Number8 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int[] nums = new int[5]; // nums [0] ~ [4]

		for (int i = 0; i < nums.length; i++) {
			System.out.print("num" + (i + 1) + " : ");
			nums[i] = sc.nextInt();

		}

		System.out.println(" <PRINT> ");
		for (int i = 0; i < nums.length; i++) {
			System.out.print(nums[i] + " ");
		}
		System.out.println();

	}

}
