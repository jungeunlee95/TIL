package Day4Homework;

import java.util.Scanner;

public class Number6ect {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("ù��° �� : ");
		int dan = sc.nextInt();
		
		System.out.print("�ι�° �� : ");
		int dan2 = sc.nextInt();
		
		
		System.out.println("*** "+ dan + "�� ***");
		for(int i = 1; i<10; i++) {
			for(int j = 1; j <10; j++) {
			}
			int num = dan * i;
			System.out.println(dan + "X" + i + "=" + num);
		} 
		System.out.println();
		
		System.out.println("*** "+ dan2 + "�� ***");
		for(int i = 1; i<10; i++) {
			for(int j = 1; j <10; j++) {
			}
			int num = dan2 * i;
			System.out.println(dan2 + "X" + i + "=" + num);
		} 
		System.out.println();
		
		
		/*
		for(int mod = 0; mod <=1; mod++) {
			System.out.println("*** " + (mod == dan ? dan : dan2 ) + "�� ***");
			for (int i = 1; i <10; i++) {
				for(int j = 1; j <10; j++) {				
				}
				if (mod == dan) {
					int num = dan * i; 
					System.out.println(dan + "X" + i + "=" + num);
				} else {
					int num2 = dan2 * i ;
					System.out.println(dan2 + "X" + i + "=" + num2);
				}
			}
			
		} System.out.println();
		*/

	}

}

