package Day10Homework02;

public class LottoMain {

	public static void main(String[] args) {
		//���� 2
		System.out.println("lotto game 2");
		new LottoVw().start();
		
	}

}
