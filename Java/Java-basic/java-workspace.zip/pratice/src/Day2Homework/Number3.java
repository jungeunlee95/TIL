package Day2Homework;

public class Number3 {

	public static void main(String[] args) {
		/*
		 *3 반지름이 10인 원의 면적을 구해서 출력하시오
		참고 : 원주율 – 3.141592
		결과출력 : 원의 면적은 143.1234 입니다.

		원의 면적 : pi * r^2
		pi = -3.141592

		 */
		//int 정수   double 실수
				int radius = 10;
				double PI = -3.141592;  
				
				System.out.println("원의 면적 = " + (radius * radius * PI) + "입니다.");

			

		}

	}


