package Day3Homework;
/*������ �ҽ� Ȯ���ϱ� ....�� ...............��..+

----*         
---***       
--*****       
-*******     
*********     
-*******     
--*****          
---***        
----*  
       
 */


public class Tnumber21 {

	public static void main(String[] args) {
		
		int k = 4;
		for(int i = 1; i<=9; i++) {
			for(int j = 1; j <=9; j++) {
				if(j <=k || j>= 10-k) {
					System.out.print('-');
				} else {
					System.out.print('*');
				}
			}
			System.out.println();
			
			if( i < 5 ) {
				k--;
			}else {
				k++;
			}
		}
		
		/*
		int space = 4, star = 1;   //space='-' ����
		
		for(int j =1; j<=space; j++) {
			System.out.print('-');
		}
		for(int j = 1; j <= star; j++) {
			System.out.print('*');
		}
		System.out.println();
		
		if(int i < 5) {
			space--;
			star +=2;
		}else {
			space++;
			star -=2;
		}
*/
	}

}
