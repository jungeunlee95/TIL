package Day10Homework;

public class LottoMain {

	public static void main(String[] args) {
		//���� 1
		System.out.println("lotto game 1");
		new LottoVw().start();
		
	}

}

