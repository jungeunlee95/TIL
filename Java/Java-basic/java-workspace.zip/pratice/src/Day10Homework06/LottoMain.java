package Day10Homework06;

public class LottoMain {

	public static void main(String[] args) {
		//���� 6
		System.out.println("lotto game 6");

		MC mc  = new MC();
		
		try {
		mc.mentStart();  
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
