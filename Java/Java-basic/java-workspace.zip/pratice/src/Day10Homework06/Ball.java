package Day10Homework06;

public class Ball {

	private int number;
	
	public Ball(int number) {
		this.number = number;
	}
	
	public int getNumber() {
		return number;
	}
}
