package Day7Homework;

import java.util.Random;

public class AreaMain {
	
	AreaMain() {
		
	}
	
	int AreMain(int a) {
		if(a == 1 && a==4) {
			Random r = new Random();
			
		}
		
		return a;
		
	}

}
