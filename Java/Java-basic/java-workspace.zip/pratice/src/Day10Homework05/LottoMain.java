package Day10Homework05;

public class LottoMain {

	public static void main(String[] args) {
		//���� 4
		System.out.println("lotto game 5");
		new LottoVw().start();
		
	}

}
