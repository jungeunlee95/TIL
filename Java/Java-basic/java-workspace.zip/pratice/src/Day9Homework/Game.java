package Day9Homework;

public interface Game {
	
	void startGame();
}
