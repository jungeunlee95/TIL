package Day10Homework03;

public class LottoMain {

	public static void main(String[] args) {
		//���� 3
		System.out.println("lotto game 3");
		new LottoVw().start();
		
	}

}
