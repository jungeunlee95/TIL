package Day10Homework03;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class LottoVw {
	private Scanner sc = new Scanner(System.in);

	public void start() {

		System.out.println("���Ӽ��� �Է��ϼ��� : ");
		// Double.parseDouble(sc.nextLine()); ������ ���� ��,
		int gameCnt = Integer.parseInt(sc.nextLine());

		for (int i = 1; i < gameCnt + 1; i++) {
			System.out.println(i + "���� : " + getLottoNums());
		}

	}

	private String getLottoNums() {
		int[] lottoNums = new int[6];
		int[] nums = new int[45];
		for (int i = 0; i < nums.length; i++) { //0~44
			nums[i] = i + 1;                    //1~45
		}
		
		Random r = new Random();
		for (int i = 0; i < 6; i++) {
			int random = r.nextInt(45 - i) + i;

			int temp = nums[i];
			nums[i] = nums[random];
			nums[random] = temp;

			lottoNums[i] = nums[i];
		}

		return Arrays.toString(lottoNums);
	}

}
