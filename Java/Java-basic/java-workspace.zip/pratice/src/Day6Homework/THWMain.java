package Day6Homework;

public class THWMain {

	public static void main(String[] args) {
		
		MethodControl control = new MethodControl();
		control.process();
		
	}

}
