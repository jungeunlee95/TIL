package DAY1;

public class HelloWorldPrint {
	public static void main(String[] args) {
		System.out.println("ȫ�浿");
		System.out.println("Hello world");
		
		double num = 0.1;
		double num2 = Math.ceil(num);
		System.out.println(num2);
	}

	
}
