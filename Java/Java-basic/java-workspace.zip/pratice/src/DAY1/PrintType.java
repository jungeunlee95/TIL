package DAY1;
/*printf
 * System.out.printf("%f",25.26);
		System.out.printf("%s","ABC");
		System.out.printf("%d",3246);
		System.out.printf("%c",'A');
		
 *      %c:����
*       %d:����
*       %f:�Ǽ�
*       %s:���ڿ�
*       */

public class PrintType {
	public static void main(String[] args) {
		System.out.println("[    A]");
		System.out.println("[   12]");
		System.out.printf("[%5c] ", 'A');
		System.out.println();
		System.out.printf("[%-5c]", 'A');
		System.out.println();
		System.out.printf("[%5d]", 123);
		System.out.println();
		System.out.printf("%f", 12.345);
		System.out.println();
		System.out.printf("%.3f", 12.345); 
		System.out.println();
		
		
		System.out.println(1 + "+" + 2 + "=" + (1+2));  //��ȣ�� �ľ��� 1+2 ���� ���� ����
		System.out.printf("%d + %d = %d", 1, 2, 1+2);
		System.out.println();
		System.out.println('A'+ "BC"); // ABC
		System.out.println(3 + 12);    // 15
		System.out.println(2.3 + 5);   // 7.3
		System.out.println('A'+'B');   // 131 �����ڵ��� A=65 B=66 =131 
		System.out.println('A'+10);    // 75
		System.out.println('\u0041');  // A 
		
		
		
		System.out.printf("���� : %c, ���� : %d",'A',3246);
		System.out.println();
		
		System.out.println("���� : " + 'A' + ", ���� : " + 3246 ); //���� : A
	}
}
