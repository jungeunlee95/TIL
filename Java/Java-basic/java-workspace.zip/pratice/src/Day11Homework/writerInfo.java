package Day11Homework;

public class writerInfo {
	
	private int num;
	private String name;
	private String time;
	private String title;
	
	public writerInfo() {
		super();
	}

	
	
	

}
