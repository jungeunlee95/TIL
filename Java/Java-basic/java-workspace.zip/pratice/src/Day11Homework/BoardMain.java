package Day11Homework;

public class BoardMain {

	public static void main(String[] args) {
		
		Menu menu = new Menu();
		
		menu.start();

	}

}
