package Day11Homework;

public class Choice {

}
