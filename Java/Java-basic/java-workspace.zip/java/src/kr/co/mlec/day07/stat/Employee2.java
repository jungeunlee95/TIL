package kr.co.mlec.day07.stat;

public class Employee2 {

	private String name;
	private int age;
	private String gender;

	static int totalCnt;

	Employee2() {
		totalCnt++;
	}

	static void emCntInfo() {
		System.out.println("----------------------------");
		System.out.println("�Ի��� �� �ο� �� : " + totalCnt + "��");
		System.out.println("----------------------------");
	}

	Employee2(String name, int age, String gender) {
		this.age = age;
		this.name = name;
		this.gender = gender;

		System.out.println(name + " ����� �Ի��߽��ϴ�.");
		totalCnt++;

	}

	void info() {

		System.out.println("�̸� : " + name + ", ���� : " + age + ", ���� : " + gender);
	}

}
