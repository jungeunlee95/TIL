package kr.co.mlec.day03.exam;
/*
 * 12345
 * 12345
 * 12345
 *
 */
public class ExamMain02 {

	public static void main(String[] args) {
		
		for(int i = 1 ; i <= 3 ; i++) {

			for(int j = 1 ; j <= 5 ; j++) {

				System.out.print(j);

			}

			System.out.println();

		}
		System.out.println("----------");
/*
12345
23456
34567
45678
56789
 */
		for(int i = 1; i <= 5; i++) {
			
			for(int j = i; j < i+5 ; j++) {
			
				System.out.print(j);
			
			}
			
			
			System.out.println();
		
		}
		System.out.println("----------");
/*
 * 56789
 * 45678
 * 34567
 * 23456
 * 12345
 * 
 */
		for(int i = 5; i > 0; i--) {
			for(int j = i; j < i + 5; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
	}

}
