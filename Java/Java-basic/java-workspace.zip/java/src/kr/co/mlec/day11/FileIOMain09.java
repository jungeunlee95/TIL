package kr.co.mlec.day11;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import kr.co.mlec.util.FileCloseUtil;

public class FileIOMain09 {

	public static void main(String[] args) {

		List<UserVO> list = new ArrayList<>();
		UserVO uv = new UserVO();
		
		list.add(new UserVO("ȫ�浿", "010-1111-2222" , "���ν�"));
		list.add(new UserVO("���浿", "010-3333-2222" , "�����"));
		list.add(new UserVO("�ֱ浿", "010-4444-2222" , "��õ��"));

		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		
		try {
			fos = new FileOutputStream("Iotest/user.txt");
			oos = new ObjectOutputStream(fos);
			
			for ( int  i = 0; i < list.size(); i++) {
				oos.writeObject(list.get(i));
			}
			
			oos.flush();
			System.out.println("���� ������ �Ϸ��߽��ϴ�");
		} catch (Exception e ) {
			e.printStackTrace();
		} finally {
			FileCloseUtil.close(fos);
			FileCloseUtil.close(oos);
		}
	}

}
