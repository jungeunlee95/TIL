package kr.co.mlec.day03.exam;
/*
 5
 4
 3
 2
 1
 */
public class ExamMain01 {

	public static void main(String[] args) {
		
		for(int i = 1; i <= 5; i++) {
		
			System.out.print(6-i);
			
			System.out.println();
		
		}
		
		for(int i = 5; i >= 1; i--) {
			System.out.print(i);
			System.out.println();
		}

	}

}
