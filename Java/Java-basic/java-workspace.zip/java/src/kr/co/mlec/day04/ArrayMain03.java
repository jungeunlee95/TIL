package kr.co.mlec.day04;

public class ArrayMain03 {

	public static void main(String[] args) {
		
		//10,20,30,40,50�� ������ �迭 ����
		
//		int[] iArr = {10, 20, 30, 40, 50};
		int[] iArr = new int[] {10,20,30,40,50};
		
		for(int i = 0; i < iArr.length; i++) {
			System.out.print(iArr[i] + " ");
		}
		
		System.out.println();
		
		//100 200 300 400 500 600 700 �迭 ����
		
//		arr = {100, 200, 300, 400, 400, 500, 600, 700};
		iArr = new int[] {100, 200, 300, 400, 400, 500, 600, 700};
		
		
		}
	
	}


