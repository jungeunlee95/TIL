package kr.co.mlec.day11;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileIOMain03 {

	public static void main(String[] args) {
		
//���۸� ����� dog.jpg => dog3.jpg ����
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		
		try {   
			fis = new FileInputStream("Iotest/DOG.jpg");
			fos = new FileOutputStream("Iotest/DOG3.jpg");
			
			bis = new BufferedInputStream(fis);
			bos = new BufferedOutputStream(fos);
			
			while(true) {
				int c = bis.read();
				if(c == -1) break;
				bos.write(c);
			}
			
			System.out.println("���� ���� �Ϸ�...");
		} catch (Exception e) {
			e.printStackTrace();  
			//���� fis fos bis bos 4���ϱ� close 4��!
			//���� ���� �ݰ� ���� �ݾ�
		} finally {
			if( bis != null) {
				try {
					bis.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			if( bos != null) {
				try {
					bos.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if( fis != null) {
				try {
					fis.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if( fos != null) {
				try {
					fos.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
