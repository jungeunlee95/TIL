package kr.co.mlec.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import kr.co.mlec.util.ConnectionFactory;
import kr.co.mlec.util.JDBCClose;

public class SelectMain03 {

	public static void main(String[] args) {
	
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = ConnectionFactory.getConnection();
		
			Scanner sc = new Scanner(System.in);
			System.out.print("�˻��� ���̵� �Է� : ");
			String id = sc.nextLine();
					
			StringBuilder sql = new StringBuilder();
			sql.append("select id, name "
					+ "from t_test "
					+ "where id = ? ");
			                          //��Ʈ�� ����,���� Ŭ������ �����͸� ��Ʈ�� �����ͷ� �ٲ���.
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			
			ResultSet rs = pstmt.executeQuery();
			
			System.out.println("[ �˻���� ]");
			while(rs.next()) {
				String user = rs.getString("id");
				String name = rs.getString("name");
				System.out.println("id : " + user  + ", name : " + name);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.close(conn, pstmt);
		}
	}

}
