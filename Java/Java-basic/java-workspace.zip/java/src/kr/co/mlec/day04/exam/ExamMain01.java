package kr.co.mlec.day04.exam;

import java.util.Scanner;

/*
 
5���� ������ �Է� �޾� ����ϴ� �ڵ带 �ۼ�
num1: 5
num2: 12
num3: 21
num4: 45
num5: 34


 */
public class ExamMain01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] nums = new int[5];   //nums [0] ~ [4]
		
		for(int i= 0; i < nums.length; i++) {
			System.out.print("num" + (i+1) + " : ");
			nums[i] = sc.nextInt();
			
		}
		
		System.out.println(" <PRINT> ");
		for(int i = 0; i < nums.length; i++) {
			System.out.print(nums[i] + " ");
		}
		System.out.println();
	
	}

}
