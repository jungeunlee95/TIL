package kr.co.mlec.day11;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileIOMain04 {

	public static void write() {
		FileOutputStream fos = null;
		DataOutputStream dos = null;

		try {
			fos = new FileOutputStream("Iotest/writer.txt");
			dos = new DataOutputStream(fos);

			char c = 'A';
			int num = 123;

//			fos.write(c);       //��� 1����Ʈ!
//			dos.writeLong(num);  //��� 8
			dos.writeChar(c); // ��� ���� �����̶� 2����Ʈ
			dos.writeInt(num); // ��� 4����Ʈ

			System.out.println("������ �Ϸ� �Ǿ����ϴ�. ");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (dos != null) {
				try {
					dos.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (fos != null) {
				try {
					fos.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void read() {
		FileInputStream fis = null;
		DataInputStream dis = null;

		try {
			fis = new FileInputStream("Iotest/writer.txt");
			dis = new DataInputStream(fis);

			char ch = dis.readChar();
			int num = dis.readInt();

			System.out.println("���� : " + ch);
			System.out.println("���� : " + num);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (dis != null) {
				try {
					dis.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void main(String[] args) {
//		write();

		read();

	}
}
