package kr.co.mlec.day08.cast;

public class Parent {
	public String name = "�ƹ���";
    public int age = 40;

    public void info(){
    	System.out.println("name : " + name + ", age : " + age);
    }

}
