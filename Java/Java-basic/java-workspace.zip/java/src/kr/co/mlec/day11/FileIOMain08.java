package kr.co.mlec.day11;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import kr.co.mlec.util.FileCloseUtil;

public class FileIOMain08 {

	public static void write() {

		UserInfo user = new UserInfo("ȫ�浿", 20, "����� ���ʱ�");

		FileOutputStream fos = null;
		ObjectOutputStream oos = null; // ����Ŭ������@ ȥ�ڸ��῰

		try {
			fos = new FileOutputStream("Iotest/object.txt");
			oos = new ObjectOutputStream(fos);

			oos.writeObject(user);
			System.out.println("�ߺ�.. object.txt�� ����Ϸ�...");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			FileCloseUtil.close(oos);
			FileCloseUtil.close(fos);
		}
	}

	public static void read() {

		FileInputStream fis = null;
		ObjectInputStream ois = null;

		try {
			fis = new FileInputStream("Iotest/object.txt");
			ois = new ObjectInputStream(fis);

			UserInfo user = (UserInfo) ois.readObject();
			System.out.println("�ߺ�.. ���� �б� �Ϸ� ...");
			System.out.println(user);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			FileCloseUtil.close(fis);
			FileCloseUtil.close(ois);
		}

	}

	public static void main(String[] args) {

//		write();
		read();

	}

}
