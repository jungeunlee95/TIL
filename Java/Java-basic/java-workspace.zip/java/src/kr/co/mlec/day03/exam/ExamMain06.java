package kr.co.mlec.day03.exam;
/*
 * ----*
 * ---**
 * --***
 * -****
 * *****
 * -****
 * --***
 * ---**
 * ----*
 * 
 * for5�� if�ϳ�
 * for3�� if3��
 * for3�� if1��
 * for2�� if2��
 */

public class ExamMain06 {
	public static void main(String[] args) {
		//for3 if3
		//�����Լҽ� Ȯ��
		
				
		// for5�� if�ϳ�
		for (int i = 1; i <= 9; i++) {
			if (i <= 5) {
				for (int j = 1; j <= 5-i; j++) {
					System.out.print('-');
				}
				for(int j = 1; j <= i; j++) {
					System.out.print('*');
				}
				
			} else {
				for (int j = 1; j <= i - 5; j++) {
					System.out.print('-');
				}
				for (int j = 1; j<= 10-i; j++) {
					System.out.print("*");
				}
			}
		
			System.out.println();
		}
       
	}
}
