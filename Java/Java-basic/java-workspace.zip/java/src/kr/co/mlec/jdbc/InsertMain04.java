package kr.co.mlec.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;

import kr.co.mlec.util.ConnectionFactory;
import kr.co.mlec.util.JDBCClose;

public class InsertMain04 {

	public static void main(String[] args) {

		Connection conn = null;
		PreparedStatement pstmt  = null;
		
		try {
			// 1~2�ܰ� �ذ�
			conn = ConnectionFactory.getConnection();

			// 3,4�ܰ�
			String sql = "insert into t_test(id,name) ";
			       sql += " values('choi', '�ֱ浿') ";
			
			pstmt = conn.prepareStatement(sql);

			int cnt = pstmt.executeUpdate();
			
			System.out.println("��" + cnt + "���� ���� �����߽��ϴ�.");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			JDBCClose.close(conn, pstmt);
			
		}

	}

}
