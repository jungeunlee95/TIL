package kr.co.mlec.day08.inter.type02;

public class SamsungTV implements TV {

	@Override
	public void powerOn() {
		// TODO Auto-generated method stub

	}

	@Override
	public void powerOff() {
		// TODO Auto-generated method stub

	}

	@Override
	public void channelUp() {
		// TODO Auto-generated method stub

	}

	@Override
	public void channelDown() {
		// TODO Auto-generated method stub

	}

	@Override
	public void soundUp() {
		// TODO Auto-generated method stub

	}

	@Override
	public void soundDown() {
		// TODO Auto-generated method stub

	}

	@Override
	public void mute() {
		// TODO Auto-generated method stub

	}

}
