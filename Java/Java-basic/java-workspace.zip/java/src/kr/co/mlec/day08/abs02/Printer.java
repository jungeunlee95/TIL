package kr.co.mlec.day08.abs02;

public abstract class Printer {
	
	private String productName;
	public abstract void print();
	
}
